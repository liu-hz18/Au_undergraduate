#pragma once

#include "AbstractFactory.h"

class HumanFactory: public AbstractFactory {
public:
    Casern* createCasern() override{
        HumanCasern* humancasern = new HumanCasern("HumanCasern");
        return humancasern;
    }
    Footman* createFootman(std::string _name) override{
        HumanFootman* humanfootman = new HumanFootman(_name);
        return humanfootman;
    }
    Commander* createCommander(std::string _name) override{
        HumanCommander* humancommander = new HumanCommander(_name);
        return humancommander;
    }
    Belong* createBelong(Footman* footman, Commander* commander) override{
        HumanBelong* humanbelong = new HumanBelong(footman, commander);
        return humanbelong;
    }
};

class OrcFactory : public AbstractFactory {
public: 
    Casern* createCasern() override{
        OrcCasern* orccasern = new OrcCasern("OrcCasern");
        return orccasern;
    }
    Footman* createFootman(std::string _name) override{
        OrcFootman* orcfootman = new OrcFootman(_name);
        return orcfootman;
    }
    Commander* createCommander(std::string _name) override{
        OrcCommander* orccommander = new OrcCommander(_name);
        return orccommander;
    }
    Belong* createBelong(Footman* footman, Commander* commander) override{
        OrcBelong* orcbelong = new OrcBelong(footman, commander);
        return orcbelong;
    }
};
