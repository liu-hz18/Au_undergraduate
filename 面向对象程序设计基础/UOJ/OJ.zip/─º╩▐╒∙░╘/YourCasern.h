#pragma once

#include "Footman.h"
#include "Commander.h"
#include "Belong.h"
#include "Casern.h"

class HumanFootman :  public Footman {
public:
    HumanFootman(std::string _name): Footman(_name){}
};

class OrcFootman :  public Footman {
public:
    OrcFootman(std::string _name): Footman(_name){}
};


class HumanCommander :  public Commander {
public:
    HumanCommander(std::string _name): Commander(_name){}
};

class OrcCommander :  public Commander {
public:
    OrcCommander(std::string _name): Commander(_name){}
};


class HumanBelong :  public Belong {
public:
    HumanBelong(Footman* _f, Commander* _c): Belong(_f, _c){}
};

class OrcBelong :  public Belong {
public:
    OrcBelong(Footman* _f, Commander* _c): Belong(_f, _c){}
};


class HumanCasern : public Casern {
public:
    HumanCasern(std::string _casernId):Casern(_casernId){}
    std::string getKind() override{ return casernId; }
};

class OrcCasern : public Casern {
public:
    OrcCasern(std::string _casernId):Casern(_casernId){}
    std::string getKind() override{ return casernId; }
};
