#pragma once
#include "Footman.h"
#include "Commander.h"
#include "Belong.h"
#include <vector>
#include <string>


class Casern {
    std::vector<Footman*> footmanVec;
    std::vector<Commander*> commanderVec;
    std::vector<Belong*> belongVec;

protected:
    std::string casernId;

public:
    virtual std::string getKind() = 0;
    
    Casern(std::string _casernId){ casernId = _casernId; }
    
    Footman* getFootmanbyIndex(int id){ return footmanVec[id]; }
    Commander* getCommanderbyIndex(int id){ return commanderVec[id]; }
    Belong* getBelongbyIndex(int id){ return belongVec[id]; }

    void addFootman(Footman* f){ footmanVec.push_back(f); }
    void addCommander(Commander* c){ commanderVec.push_back(c); }
    void addBelong(Belong* b){ belongVec.push_back(b); }

};