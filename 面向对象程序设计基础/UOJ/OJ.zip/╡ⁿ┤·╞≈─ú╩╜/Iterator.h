
#pragma once

class Iterator{

public:
    virtual ~Iterator() = 0;
    virtual bool hasNext()const = 0;
    virtual int next() = 0;

};

Iterator::~Iterator(){}