
#pragma once

#include "Collection.h"
#include "ArrayIterator.h"
#include <vector>
#include <algorithm>
using std::vector;

class ArrayCollection: public Collection{
    friend class ArrayIterator;
    std::vector<int> vec;

public:
    void push(int num){
        vec.push_back(num);
    }
    int size()const{
        return vec.size();
    }
    void sortCollection(){
        sort(vec.begin(), vec.end());
    }
    ArrayIterator* iterator(){
        ArrayIterator* iter = new ArrayIterator(&vec);
        return iter;
    }
    int begin()const {
        return vec[0];
    }
    int end()const {
        return vec.back();
    }

};