
#include <iostream>
#include "ArrayCollection.h"
#include "ListCollection.h"
#include "ArrayIterator.h"
#include "ListIterator.h"
#include "Iterator.h"

using namespace std;

int main(){
    ArrayCollection array;
    ListCollection list;
    int n, num;
    cin >> n;

    while(n--){
        cin >> num;
        array.push(num);
        list.push(num);
    }

    array.sortCollection();
    list.sortCollection();

    Iterator* array_it = array.iterator();
    while(array_it->hasNext()){
        cout << array_it->next() << " ";
    }
    cout << endl;

    Iterator* list_it = list.iterator();
    while(list_it->hasNext()){
        cout <<list_it->next() << " ";
    }
    cout << endl;
    return 0;
}
