
#pragma once

#include <vector>
#include "Iterator.h"
using std::vector;

class ArrayIterator: public Iterator{
    std::vector<int>::iterator iter;
    std::vector<int>* ptr_vec;

public:
    ArrayIterator(std::vector<int>* vec){ 
        ptr_vec = vec;
        iter = vec->begin();
    }
    bool hasNext() const{
        return iter != ptr_vec->end();
    }
    int next(){
        return *(iter++);
    }
    
};