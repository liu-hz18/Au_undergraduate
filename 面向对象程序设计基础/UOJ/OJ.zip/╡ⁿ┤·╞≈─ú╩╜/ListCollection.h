
#pragma once

#include "Collection.h"
#include "ListIterator.h"
#include <list>
#include <algorithm>
using std::list;

class ListCollection: public Collection{
    friend class ListIterator;
    std::list<int> alist;

public:
    void push(int num){
        alist.push_back(num);
    }
    int size()const{
        return alist.size();
    }
    void sortCollection(){
        alist.sort();
    }
    ListIterator* iterator(){
        ListIterator* iter = new ListIterator(&alist);
        return iter;
    }
    int begin() const {
        return alist.front();
    }
    int end() const {
        return alist.back();
    }
};
