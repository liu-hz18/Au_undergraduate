
#pragma once

#include "Iterator.h"

//容器抽象接口类
class Collection{

public:
    virtual ~Collection() = 0;
    virtual int begin()const = 0;
    virtual int end()const = 0;
    virtual int size()const  = 0;
    virtual void sortCollection() = 0;
    virtual void push(int) = 0;
};

Collection::~Collection(){}
