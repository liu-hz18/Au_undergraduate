
#pragma once
#include <list>
#include "Iterator.h"
#include <list>
using std::list;

class ListIterator: public Iterator{
    list<int>* ptr_list;
    list<int>::iterator iter;

public:
    ListIterator(list<int>* alist){
        ptr_list = alist;
        iter = alist->begin();
    }
    bool hasNext() const {
        return iter != ptr_list->end();
    }
    int next(){
        return *(iter++);
    }
    
};