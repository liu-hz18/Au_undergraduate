
#include "Node.h"

class Array{
    int len;
    Node* nodeArray;

public:
    Array(int _len);
    ~Array();
    void update(const int& q, const int& r);
    void swap(const int& q, const int& r);
    void insert(const int& q, const int& r);
    Node& operator[](const int& id);

};