
#include "Array.h"

Array::Array(int _len): len(_len){
    nodeArray = new Node[len];
};
Array::~Array(){
    delete[] nodeArray;
}
void Array::update(const int& q, const int& r){
    nodeArray[q] = nodeArray[r];
}
void Array::swap(const int& q, const int& r){
    Node tmp(std::move(nodeArray[q]));
    nodeArray[q] = std::move(nodeArray[r]);
    nodeArray[r] = std::move(tmp);
}
void Array::insert(const int& q, const int& r){
    //顺序后移
    for(int i = len-1; i > q; i--){
        nodeArray[i] = std::move(nodeArray[i-1]);
    }
    nodeArray[q] = std::move(Node(r));
}
Node& Array::operator[](const int& id){
    return nodeArray[id];
}