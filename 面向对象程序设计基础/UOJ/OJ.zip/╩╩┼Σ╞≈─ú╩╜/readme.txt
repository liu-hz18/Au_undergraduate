适配器模式：
构建从B到A的转换器类Adapter，只需要Adapter继承A类，成员设为B类指针即可。
由于继承性，所有针对Adapter父类的方法都可以经过向上转换识别Adapter类指针，实现“适配”