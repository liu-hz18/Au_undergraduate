
#include "Shape.h"

Rectangle::Rectangle(double _length, double _width): length(_length), width(_width){};
double Rectangle::getArea(){
    return length * width;
}

Circle::Circle(double r): radius(r){};
double Circle::getArea(){
    return PI * radius * radius;
}
