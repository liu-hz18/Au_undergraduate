
#include <math.h>

//const double PI = acos(-1.0);
const double PI = 3.14;

class Shape{
public:
    virtual double getArea() = 0;
};

class Rectangle: public Shape{
    double length, width;
public:
    Rectangle(double _length, double _width);
    double getArea();
};

class Circle: public Shape{
    double radius;
public:
    Circle(double r);
    double getArea();
};
