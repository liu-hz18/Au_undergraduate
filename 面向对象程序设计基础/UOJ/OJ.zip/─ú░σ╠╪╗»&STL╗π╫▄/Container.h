#ifndef CONTAINER_H
#define CONTAINER_H

#include "BasicContainer.h"
#include <vector>
#include <set>
#include <algorithm>
#include <list>
#include <queue>

using std::vector;
using std::multiset;

//容器使用了迭代器，所以不支持queue和stack
template<class A, class C>
class Container : public BasicContainer<A>{
    C base;
public:
    void insert(const A &x){
        for(auto t = base.begin(); t != base.end(); ++t)
            if(*t > x){//有序插入
                base.insert(t, x);
                return;
            }
        base.insert(base.end(), x);
    }
    A find(int k){
        auto t = base.begin();
        while(--k)
            ++t;
        return *t;
    }
};

//vector模板特化,A可以是int或string
template<class A>
class Container<A, vector<A> >: public BasicContainer<A> {
    vector<A> vec;
    bool sorted;

public:
    Container(){ sorted = false; }
    void insert(const A& x){//O(1)
        vec.push_back(x);
    }
    A find(int k){//O(1)
        if(!sorted){
            sort(vec.begin(), vec.end());//O(nlogn)
            sorted = true;
        }
        return vec[k-1];
    }
};

//multiset集合，已经实现了排序
template<class A>
class Container<A, multiset<A> >: public BasicContainer<A>{
    multiset<A> aset;

public:
    void insert(const A& x){
        aset.insert(x);
    }
    A find(int k){
        auto t = aset.begin();
        while(--k)
            ++t;
        return *t;
    }
    
};

#endif
//set(key), map(key-value)一族： 底层为红黑树，迭代器插入删除均不失效。插入O(logn),删除O(logn),查找O(logn),遍历均摊O(1).
    //已经排序好，multi系列允许有相同元素。
//vector: 底层数组，迭代器插入删除:操作点后面的点会失效。
//list: 底层双向链表，迭代器插入删除不会失效。排序用list.sort()
//deque: 双向队列，底层块状链表(缓冲)。 首尾 插入删除 迭代器不会失效，中间会失效。支持首尾操作。
//stack/queue:栈/队列，底层deque(块状链表)。没有迭代器!!!
//priority_queue: 优先级队列，底层默认为vector，默认为大顶堆。
