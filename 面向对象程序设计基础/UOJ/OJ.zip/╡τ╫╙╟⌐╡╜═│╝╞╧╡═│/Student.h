
#pragma once
#include <string>

class Student{
    friend class ClassSystem;
    std::string name;
    int presentTime, absentTime;

public:
    Student(std::string _name);
    std::string& getName();
    int getPresentTimes();
    int getAbsentTimes();

};