
#pragma once

#include "Student.h"
#include <vector>
#include <string>

class ClassSystem{
    std::vector<Student> vec;
    int num;

public:
    void addStudent(Student& stu);
    void addClassNumber();
    void signIn(const std::string& name);
    Student getStudentByName(const std::string name)const;
    Student getStudentById(int id)const;
    
};