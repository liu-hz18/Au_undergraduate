
#include "ClassSystem.h"

void ClassSystem::addStudent(Student& stu){
    vec.push_back(stu);
}

void ClassSystem::addClassNumber(){
    num++;
    for(auto& item : vec){
        item.absentTime ++;
    }
}

void ClassSystem::signIn(const std::string& name){
    for(auto& item: vec){
        if(item.name == name){
            item.absentTime --;
            item.presentTime ++;
        }
    }
}

Student ClassSystem::getStudentByName(const std::string name)const {
    for(auto& item: vec){
        if(item.name == name)return item;
    }
    return vec[0];
}

Student ClassSystem::getStudentById(int id)const {
    return vec[id];
}
