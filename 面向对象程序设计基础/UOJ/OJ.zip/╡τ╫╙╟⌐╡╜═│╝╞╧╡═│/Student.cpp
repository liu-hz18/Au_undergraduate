
#include "Student.h"

Student::Student(std::string _name): name(_name), presentTime(0), absentTime(0){}
std::string& Student::getName(){
    return name;
}
int Student::getPresentTimes(){
    return presentTime;
}
int Student::getAbsentTimes(){
    return absentTime;
}
