
#include "Node.h"

class Array{
    Node* nodeArray;
    int len;
public:
    Array(int _len);
    Array(const Array& arr);
    Array(Array &&arr);
    ~Array();
    Node& operator[](const int& id);
    Array& operator=(const Array& arr);
    Array& operator=(Array&& arr);
    
};

