
#include "Array.h"

Array::Array(int _len): len(_len){//Constructor
    nodeArray = new Node[_len];
};
Array::Array(const Array& arr): len(arr.len){//Copy Constructor
    nodeArray = new Node[len];
    for(int i = 0; i < len; i++)nodeArray[i] = arr.nodeArray[i];
}
Array::Array(Array &&arr): nodeArray(arr.nodeArray){//move Constructor
    arr.nodeArray = nullptr;
}
Array::~Array(){
    delete[] nodeArray;
}
Node& Array::operator[](const int& id){
    return nodeArray[id];
}
Array& Array::operator=(const Array& arr){
    if(this != &arr){
        for(int i = 0; i < len; i++)nodeArray[i] = arr.nodeArray[i];
    }
    return *this;     
}
Array& Array::operator=(Array&& arr){
    if(this != &arr){
        nodeArray = arr.nodeArray;
        arr.nodeArray = nullptr;
    }
    return *this;
}