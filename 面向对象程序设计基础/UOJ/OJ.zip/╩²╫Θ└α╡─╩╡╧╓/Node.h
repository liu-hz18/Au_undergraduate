#pragma once
#include <iostream>

struct Node{
private:
	static int createTimes, copyCreateTimes, \
			moveCreateTimes, copyAssignTimes, moveAssignTimes, delTimes;
	int val;
public:	
	Node(int v = 0);//构造
	~Node();
	Node(const Node &y);//拷贝构造
	Node(Node &&y);//移动构造
	Node& operator=(const Node &y);//拷贝赋值
	Node& operator=(Node &&y);//移动赋值
	friend std::istream& operator>>(std::istream& in, Node& x);
	friend std::ostream& operator<<(std::ostream& out, const Node& x);
	static void outputResult();
};
