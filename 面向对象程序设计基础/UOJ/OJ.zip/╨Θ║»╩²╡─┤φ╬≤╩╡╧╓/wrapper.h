
#include "wrapper_counter.h"

class AbstractWrapper {
	string uid;
public:
	AbstractWrapper() {}
	virtual ~AbstractWrapper() = 0;
	string& getuid(){ return uid; }
	virtual string type() = 0;
	virtual string to_string() = 0;
	friend ostream &operator <<(ostream &out, AbstractWrapper *w) {
		return out << w->uid << ": " << w->to_string();
	}
};

//纯虚析构函数必须有函数体，以使得基类成为抽象类，不能创建基类的对象
AbstractWrapper::~AbstractWrapper(){}

class IntegerWrapper : public AbstractWrapper {
	int *ptr;
public:
	IntegerWrapper(int *ptr) 
		: AbstractWrapper(), ptr(ptr) {
			getuid() = WrapperCounter::getUID(type());
		}
	virtual ~IntegerWrapper(){ 
		if(ptr){ delete ptr; ptr = nullptr; } 
	}
	virtual string type() override { return "int"; }
	virtual string to_string() override {
		return std::to_string(*ptr);
	}
};

class StringWrapper : public AbstractWrapper {
protected:
	char *ptr;
	int len;
public:
	StringWrapper(char *ptr, int len, bool usename = true)
		: AbstractWrapper(), ptr(ptr), len(len) {
			if(usename)getuid() = WrapperCounter::getUID(type());
		}
	virtual ~StringWrapper() { 
		if(ptr){ delete[] ptr; ptr = nullptr; } 
	}
	int length() { return len; }
	virtual string type() override { return "string"; }
	virtual string to_string() override {
		return string(ptr, len);
	}
};

class ChineseStringWrapper : public StringWrapper {
	// 用三个char表示一个汉字

public:
	ChineseStringWrapper(char *ptr, int len)
		: StringWrapper(ptr, len, false) {
			getuid() = WrapperCounter::getUID(type());
		}
	virtual ~ChineseStringWrapper() { 
		if(ptr){ delete[] ptr; ptr = nullptr; } 
	}
	virtual string type() override { return "chineseString"; }
	int length(bool rawChars = true) {
		// 如果rawChars为false，则返回中文字符数；否则返回实际char数组长度
		if (rawChars) return len;
		else return (len / 3);
	}
	virtual string to_string() override {
		return string(ptr, len);
	}
};
