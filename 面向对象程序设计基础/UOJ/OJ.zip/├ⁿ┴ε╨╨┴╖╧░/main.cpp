
#include <iostream>
#include <cstring>
#include <algorithm>
#include <vector>
using namespace std;

inline void printinfo(){
    cout<<"usage: convert -L command digit-string"<<endl;
    cout<<"command = C|c|E|e"<<endl;
    cout<<"example: convert -L C 2018"<<endl;
}

inline void printerr(){
    cout<<"error input!"<<endl;
    printinfo();
}

void printnum(const char* command, const char* num){
    string ch[10] = {"零", "一", "二", "三", "四", "五", "六", "七", "八", "九"};
    string Ch[10] = {"零", "壹", "贰", "叁", "肆", "伍", "陆", "柒", "捌", "玖"} ;
    string en[10] = {"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"};
    int len = strlen(num);
    std::vector<string> vec;
    if(!strcmp(command, "C")){
        for(int i = 0; i < len; i++){
            if(num[i] < '0' || num[i] > '9'){printerr(); return;}
            vec.push_back(Ch[num[i] - '0']);
        }
    }else if(!strcmp(command, "c")){
        for(int i = 0; i < len; i++){
            if(num[i] < '0' || num[i] > '9'){printerr(); return;}
            vec.push_back(ch[num[i] - '0']);
        }
    }else if(!strcmp(command, "e")){
        for(int i = 0; i < len; i++){
            if(num[i] < '0' || num[i] > '9'){printerr(); return;}
            vec.push_back(en[num[i] - '0'] + " ");
        }
    }else if(!strcmp(command, "E")){
        for(int i = 0; i < len; i++){
            if(num[i] < '0' || num[i] > '9'){printerr(); return;}
            string temp = en[num[i] - '0'];
            transform(temp.begin(), temp.end(), temp.begin(), ::toupper);
            vec.push_back(temp + " ");
        }
    }
    for(auto& item : vec){
        cout<<item;
    }
    cout<<endl;
}

int main(int argc, char const *argv[]){
    if(argc == 1){
        printinfo();
    }else if(argc != 4 || strcmp(argv[1], "-L") || (strcmp(argv[2], "C") && strcmp(argv[2], "c") && strcmp(argv[2], "E") && strcmp(argv[2], "e"))){
        printerr();
    }else{
        printnum(argv[2], argv[3]);
    }
    return 0;
}