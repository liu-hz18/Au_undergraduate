
//g++ test.cpp -std=c++11 -O2 -Wall -o test.exe

#include <iostream>
using namespace std;

#define Option_A A testA = f1(b);
#define Option_B A testB = f2(b);
#define Option_C A testC = f3(b);
#define Option_D A testD = f3(b);
#define Option_E A& testE = f4(b);
#define Option_F A testF = f5(a[0]);

#include "MyAnswer.h"
#include <string>
using namespace std;

class A {
    string name;
public:
    A(const char* n){
        name = string(n);
        cout << "A constructing..." << name << endl;
    }
    A(string n){
        name = n;
        cout << "A constructing..." << name << endl;
    }
    A(){
        cout << "A constructing..." << endl;
    }
    ~A(){
        cout << "A destructing..." << name << endl;
    }
} d(string("d"));//A constructing...

class B {
    static A data1;
    A data2;//A constructing...
    string name;

public:
    B(const char* n):data2(n+string(".data2")){
        name = string(n);
        cout << "B constructing..." << name << endl;
    }
    B(){
        cout << "B constructing..." << endl;
    }
    ~B(){
        cout << "B destructing..." << name << endl;
    }

} e("e");//B constructing...

A B::data1("B::data1");//A constructing...

//5
A f1(A a){//拷贝构造
    cout << "------after call------" << endl;
    A b("b");//A constructing...
    cout << "------before return------" << endl;
    return b;
}//A destructing...

//3
A f2(A& a) {
    cout << "------after call------" << endl;
    A b("b");//A constructing...
    cout << "------before return------" << endl;
    return b;
}

//1
A f3(A a){//拷贝构造
    cout << "------after call------" << endl;
    static A b("b");//局部静态变量（一般为函数内的静态变量）在第一次使用时分配内存并初始化
    cout << "------before return------" << endl;
    return b;//
}//A destructing...

//2
A& f4(A& a) {//
    cout << "------after call------" << endl;
    A &b = a;//
    cout << "------before return------" << endl;
    return b;//
}

//4
A f5(A* a) {//
    cout << "------after call------" << endl;
    A* b = a;//
    cout << "------before return------" << endl;
    return *b;//拷贝构造
}

void work(){//A constructing...
    cout << "=======entering work=======" << endl;
    A b("b");//A constructing...
    B f("f");//B constructing...
    
    A* a[2];
    a[0] = &b;
    a[1] = new A("a[1]");//A constructing...
    
    //(1)B
    cout << "------before call------" << endl;
    Answer1
    cout << "------after return------" << endl << endl;
    
    //(2)E
    cout << "------before call------" << endl;
    Answer2
    cout << "------after return------" << endl << endl;
    
    //(3)C
    cout << "------before call------" << endl;
    Answer3
    cout << "------after return------" << endl << endl;
    
    //(4)D
    cout << "------before call------" << endl;
    Answer4
    cout << "------after return------" << endl << endl;
    
    //(5)A
    cout << "------before call------" << endl;
    Answer5
    cout << "------after return------" << endl << endl;
    
    //(6)F
    cout << "------before call------" << endl;
    Answer6
    cout << "------after return------" << endl << endl;
    
    delete a[1];//A destructing...
    cout << "=======exiting work=======" << endl;

}

int main() {
    cout << "=======entering main=======" << endl;
    work();
    cout << "=======exiting main=======" << endl;
    return 0;
}

