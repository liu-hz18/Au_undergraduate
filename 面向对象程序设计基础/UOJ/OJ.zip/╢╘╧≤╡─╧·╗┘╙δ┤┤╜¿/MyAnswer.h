
#pragma once

#define Answer1 Option_B
#define Answer2 Option_E
#define Answer3 Option_C
#define Answer4 Option_D
#define Answer5 Option_A
#define Answer6 Option_F
