
//<<重载
//sortByScore();
//>>重载
//[]重载
#ifndef _COMPUTERCOLLECTION_H_
#define _COMPUTERCOLLECTION_H_

#include "Computer.h"
#include <vector>
#include <iostream>
using namespace std;

class ComputerCollection{
    vector<Computer> comvec;

public:
    void sortByScore();
    Computer& operator[](const string& name);
    friend istream& operator>>(istream& in, ComputerCollection& com){
        Computer temp;
        in >> temp;
        com.comvec.push_back(temp);
        return in;
    }
    friend ostream& operator<<(ostream& out, const ComputerCollection& com){
        for(auto& item: com.comvec){
            out << item << endl;
        }
        return out;
    }

};

#endif