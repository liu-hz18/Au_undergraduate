
#ifndef _COMPUTER_H_
#define _COMPUTER_H_

#include <string>
#include <vector>
#include <iostream>
using namespace std;

vector<string> split(const string& str, const string& pattern);

class Computer{
    friend class ComputerCollection;
    string name;
    int stock, price;

public:
    Computer(){}
    Computer(string _name, int s, int p): name(_name), stock(s), price(p){}
    
    void setPrice(int p);
    bool operator<(const Computer& com)const;

    Computer& operator++();
    Computer& operator--();
    
    const Computer operator++( int );
    const Computer operator--( int );

    friend istream& operator>>(istream& in, Computer& com){
        string temp;
        in >> temp;
        auto strvec = split(temp, "-");
        com.name = strvec[0];
        com.stock = stoi(strvec[1]);
        com.price = stoi(strvec[2]);
        return in;
    }

    friend ostream& operator<<(ostream& out, const Computer& com){
        out << com.name << "-num-" << com.stock << "-price-" << com.price;
        return out;
    }

};

#endif