
#include "ComputerCollection.h"
#include <algorithm>

bool compare(const Computer& a, const Computer& b){
    return !(a < b);
}

void ComputerCollection::sortByScore(){
    sort(comvec.begin(), comvec.end(), compare);
}
Computer& ComputerCollection::operator[](const string& name){
    for(auto& item: comvec){
        if(item.name == name)return item;
    }
    return comvec[0];
}
