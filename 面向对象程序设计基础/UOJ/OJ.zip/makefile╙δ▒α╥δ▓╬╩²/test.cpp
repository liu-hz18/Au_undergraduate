
void function(auto a) {}

int main(int argc, char const *argv[]){
    function(10);
    return 0;
}
