#pragma once
#ifdef DEBUG
#undef DEBUG
#endif
int sum(int a, int b);
int product(int a, int b);