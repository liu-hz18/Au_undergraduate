#include "functions.h"
int product(int a, int b)
{
	return a * b;
}
