
#pragma once
#include <iostream>

class Input{
public:
    int x, y;
    Input(){
        std::cin>>x>>y;
    }
};
