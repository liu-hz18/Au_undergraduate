
#include <iostream>
#include "Test.h"
using namespace std;

Test F1(Test &&a){//无反应
    cout << "F1() in..." << endl;
    Test b = a;//拷贝赋值
    cout << "F1() exit..." << endl;
    return b;
}

Test&& F2(Test &a){//无操作
    cout <<"F2() in..."<<endl;
    Test b = a;//拷贝赋值
    cout << "F2() exit..." << endl;
    return std::move(b);//先析构b,然后移动构造返回的新变量
}

const Test& F3(const Test& a){//无反应
    cout <<"F3() in..."<<endl;
    Test b = a;//拷贝赋值
    cout << "F3() exit..." << endl;
    return std::move(b);//b析构，调用拷贝构造产生返回值
}

Test F4(const Test& a){//无反应
    cout <<"F4() in..."<<endl;
    Test b = std::move(a); //拷贝赋值
    cout << "F4() exit..." << endl;
    return b;//无反应
}

const Test& F5(Test a){//拷贝构造
    cout << "F5() in..." << endl;
    Test& b = a;//无反应
    cout << "F5() exit..." <<endl;
    return b;//拷贝构造b，析构a
}


int main(){
    Test a, b, c, d, e;

    cout << "F1() called..." << endl;
    auto f1 = F1(std::move(a));
    cout << "F1() ended...\n" << endl;
    
    cout << "F2() called..." << endl;
    auto f2 = F2(b);
    cout << "F2() ended...\n" << endl;
    
    cout << "F3() called..." << endl;
    auto f3 = F3(c);
    cout << "F3() ended...\n" << endl;
    
    cout << "F4() called..." << endl;
    auto f4 = F4(d);
    cout << "F4() ended...\n" << endl;
    
    cout << "F5() called..." << endl;
    auto f5 = F5(e);
    cout << "F5() ended...\n" << endl;

    return 0;
}
