
//配合getline(in, line)
//buffer = Readline(line);
//可以读取一行，将该行按空格分开，返回数组。
vector<string> Readline(string str){
    stringstream ss(str);
    string a;
    vector<string> buffer; 
    while(ss >> a){
        buffer.push_back(a);
    } 
    return buffer;
}