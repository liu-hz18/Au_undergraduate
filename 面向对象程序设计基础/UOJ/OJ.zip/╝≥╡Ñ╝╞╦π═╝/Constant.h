
#pragma once

#include "Value.h"

class Constant: public Value{
    int val;

public:
    Constant(int v): val(v){}
    int calc() override {
        return val;
    }
    int change(int v){
        val = v;
    }
    
};
