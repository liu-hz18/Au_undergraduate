
#pragma once

#include "Operator.h"

class SubOperator: public Operator{

public:
    SubOperator(Value* r1, Value* r2): Operator(r1, r2){}
    int calc() override {
        return getV1() - getV2();
    }

};
