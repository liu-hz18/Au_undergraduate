
#include <iostream>
#include <string>
#include "Value.h"
#include "Constant.h"
#include "Operator.h"
#include "PlusOperator.h"
#include "SubOperator.h"
#include "MultiplyOperator.h"

int n;
Value *v[100001];
std::string s;

int main(){
    std::cin >> n;
    int a, b;
    for(int i = 1; i <= n; ++i){
        std::cin >> s;
        if(s == "Constant"){
            std::cin >> a;
            v[i] = new Constant(a);
        }
        else if(s == "Plus"){
            std::cin >> a >> b;
            v[i] = new PlusOperator(v[a], v[b]);
        }
        else if(s == "Sub"){
            std::cin >> a >> b;
            v[i] = new SubOperator(v[a], v[b]);
        }
        else if(s == "Multiply"){
            std::cin >> a >> b;
            v[i] = new MultiplyOperator(v[a], v[b]);
        }
        else if(s == "Print"){
            std::cin >> a;
            std::cout << v[a]->calc() << std::endl;
            v[i] = v[a];
        }
        else if(s == "Modify"){
        	std::cin >> a >> b;
            auto tmp = dynamic_cast<Constant*>(v[a]);
            tmp->change(b);
            v[i] = v[a];
        }
    }
	return 0;
}
