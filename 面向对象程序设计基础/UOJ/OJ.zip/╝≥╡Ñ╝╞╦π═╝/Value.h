#ifndef VALUE_H
#define VALUE_H

class Value {

public:
    virtual int calc() = 0;
	virtual ~Value() {};
};

#endif
