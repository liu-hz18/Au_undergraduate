
#pragma once

#include "Operator.h"

class MultiplyOperator:  public Operator{

public:
    MultiplyOperator(Value* r1, Value* r2): Operator(r1, r2){}
    int calc() override {
        return getV1() * getV2();
    }

};