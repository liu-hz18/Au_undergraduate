
#pragma once

#include "Student.h"
#include <algorithm>
#include <iostream>
#include <string>
#include <vector>
using namespace std;

const int maxn = 250;

bool compare(const Student& a, const Student& b){
    return a > b;
}

vector<string> split(const string& str, const string& pattern){
    vector<string> strvec;
    string::size_type pos;
    string::size_type size = str.size();
    for(string::size_type i = 0; i < size; i++){
        pos = str.find(pattern, i);
        if(pos < size){
            string s = str.substr(i, pos - i);
            strvec.push_back(s);
            i = pos + pattern.size() - 1;
        }else{
            string s = str.substr(i, pos - i);
            strvec.push_back(s);
            break;
        }
    }
    return strvec;
}

class StudentCollection{
    //Student* pStudent;
    //使用map建立映射(底层红黑树)
    int count;
    Student studentList[maxn];

public:
    StudentCollection(){ 
        count = 0;
    }
    ~StudentCollection(){
    }
    void sortByScore(){
        sort(studentList, studentList + count, compare);
    }
    int find(const string& name)const{
        for(int i = 0; i < count; i++){
            if(studentList[i].name == name)return i;
        }
        return -1;
    }
    Student& operator[](const string& name){
        for(int i = 0; i < count; i++){
            if(studentList[i].name == name)return studentList[i];
        }
        return studentList[0];
    }
    friend istream& operator>>(istream& in, StudentCollection& dst){
        string temp;
        in>>temp;
        auto vec = split(temp, "-");
        int index = dst.find(vec[0]);
        if(index == -1){
            dst.studentList[dst.count].name = vec[0];
            dst.studentList[dst.count].set(vec[1], stoi(vec[2]));
            dst.count++;
        }else dst.studentList[index].set(vec[1], stoi(vec[2]));
        return in;
    }
    friend ostream& operator<<(ostream& out, const StudentCollection& src){
        for(int i = 0; i < src.count; i++){
            out<<src.studentList[i]<<endl;
        }
        return out;
    }
    
};
