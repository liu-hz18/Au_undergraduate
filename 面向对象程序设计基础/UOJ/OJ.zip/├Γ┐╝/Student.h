
#pragma once

#include <string>
#include <iostream>
#include <string>
using namespace std;

class Student{
public:
    int chinese, math, english;
    int total;
    string name;

    Student(){
        chinese = math = english = total = 0;
        name = "";
    }
    ~Student(){
    }
    void set(const string& str, int score){
        if(str == "Chinese"){
            this->chinese = score;
            this->total += score;
        }else if(str == "Math"){
            this->math = score;
            this->total += score;
        }else if(str == "English"){
            this->english = score;
            this->total += score;
        }
    }
    //如果想实现升序和降序排序，必须实现两个判等器，只有一个会出错。
    //多级比较器不能使用三目运算符嵌套！！！使用if else 来判断！！！
    bool operator<(const Student& stu)const{
        if(total < stu.total)return 1;
        else if(total == stu.total){
            if(chinese < stu.chinese)return 1;
            else if(chinese == stu.chinese){
                if(math < stu.math)return 1;
                else if(math == stu.math){
                    if(english < stu.english)return 1;
                }
            }
        }
        return 0;
    }
    bool operator>(const Student& stu)const{
        if(total > stu.total)return 1;
        else if(total == stu.total){
            if(chinese > stu.chinese)return 1;
            else if(chinese == stu.chinese){
                if(math > stu.math)return 1;
                else if(math == stu.math){
                    if(english > stu.english)return 1;
                }
            }
        }
        return 0;
    }
    friend ostream& operator<<(ostream& out, const Student& src){
        out<<src.name<<"-Total-"<<src.total<<"-Chinese-"<<src.chinese<<"-Math-"<<src.math<<"-English-"<<src.english;
        return out;
    }
};
