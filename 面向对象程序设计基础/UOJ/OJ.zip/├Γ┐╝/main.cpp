
#include <iostream>
#include <string>
using namespace std;

void ptintinfo(){
    cout<<"usage: convert -L command digit-string"<<endl;
    cout<<"command = C|c|E|e"<<endl;
    cout<<"example: convert -L C 2018"<<endl;
}


int main(int argc, char** argv) {
    if(argc == 1){
        printinfo();
    }else if(argc != 4){
        cout<<"error input!"<endl;
        printinfo();
    }else{
        char[10][10] english = {"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"};
        char[10][10] chinese = {"零","一","二","三","四","五","六","七","八","九"};
        char[10][10] Chinese = {"零","壹","贰","叁","肆","伍","陆","柒","捌","玖"};
        

    }
    return 0;
}
