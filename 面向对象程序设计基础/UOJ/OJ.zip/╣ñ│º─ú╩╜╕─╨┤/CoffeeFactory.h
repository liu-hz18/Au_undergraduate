
#ifndef _COFFEE_FACTORY_H_
#define _COFFEE_FACTORY_H_

#include <vector>
#include <string>

#include "Coffee.h"
#include "Cup.h"


class CoffeeFactory{
    std::vector<Coffee*> coffeeVec;
    std::vector<Cup*> cupVec;
    int cupused;
    void clearCup(){
        for(auto& cup: cupVec){
            if(cup){delete cup; cup = nullptr;}
        }
        cupVec.clear();
    }

public:
    CoffeeFactory(): cupused(0){ }
    virtual ~CoffeeFactory(){
        clearCoffee();
        clearCup();
    }
    Coffee* createCoffee(const std::string type, int coffee, int milk, bool brewed = false, bool mixed = false){
        if(cupused >= cupVec.size())return nullptr;
        Coffee* co = new Coffee(type, coffee, milk);
        if(brewed) co->brew();
        if(mixed) co->mix();
        co->pour_into(cupVec[cupused++]);
        coffeeVec.push_back(co);
        return co;
    }
    Cup* createCup(const std::string type){
        Cup* cu = new Cup(type);
        cupVec.push_back(cu);
        return cu;
    }
    int coffeeOrdered()const{
        return coffeeVec.size();
    }
    void drinkCoffee(bool del = false){
        for(auto& coffee: coffeeVec){
            if(coffee){
                coffee->drink();
                if(del){delete coffee; coffee = nullptr;}
            }
        }
    }
    void clearCoffee(){
        cupused = 0;
        for(auto& coffee: coffeeVec){
            if(coffee){delete coffee; coffee = nullptr;}
        }
        coffeeVec.clear();
    }
};

#endif