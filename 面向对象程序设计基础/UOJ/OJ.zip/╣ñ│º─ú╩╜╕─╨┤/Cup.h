
#ifndef _CUP_H_
#define _CUP_H_

#include "Coffee.h"
#include <string>
#include <iostream>

class Cup {
    std::string _id;
    class Coffee *coffee;

public:
    Cup(const std::string &id) : _id(id), coffee(nullptr) {}
    ~Cup() {
        std::cout << "Sold " << _id << " cup." << std::endl;
    }
    bool contains_coffee() const {
        return this->coffee != nullptr;
    }
    void hold_coffee(Coffee *coffee) {
        this->coffee = coffee;
    }
    const std::string &id() const {
        return _id;
    }
};


#endif