
#include <algorithm>
#include <iostream>
#include <vector>
#include <cassert>
#include <cmath>
#include "CoffeeFactory.h"

using namespace std;

int main() {
    CoffeeFactory factory;
    factory.createCup("red");
    factory.createCup("white");
    factory.createCup("golden");
    factory.createCup("titanium");
    factory.createCup("cat pretending to be a");

    factory.createCoffee("Espresso", 20, 0, true);
    factory.createCoffee("Macchiato", 40, 20, true, true);
    factory.createCoffee("Cappuccino", 20, 40, true);
    factory.createCoffee("Latte", 30, 90, true, true);
    factory.createCoffee("Milk", 0, 100, false);
    factory.createCoffee("Water", 0, 0, false);
    cout << "Ordered " << factory.coffeeOrdered() << " cups of coffee." << endl;
    factory.drinkCoffee(true);

    factory.clearCoffee();
    factory.createCoffee("Water", 0, 0, false);
    factory.createCoffee("Milk", 0, 100, false);
    factory.createCoffee("Latte", 30, 90, true, true);
    factory.createCoffee("Cappuccino", 20, 40, true);
    factory.createCoffee("Macchiato", 40, 20, true, true);
    factory.createCoffee("Espresso", 20, 0, true);

    cout << "Ordered " << factory.coffeeOrdered() << " cups of coffee." << endl;
    factory.drinkCoffee();

    return 0;
}
