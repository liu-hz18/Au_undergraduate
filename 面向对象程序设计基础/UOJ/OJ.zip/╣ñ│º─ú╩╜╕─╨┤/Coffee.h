
#ifndef _COFFEE_H_
#define _COFFEE_H_

#include "Cup.h"
#include <string>
#include <iostream>


class Coffee {
    friend class CoffeeFactory;
    std::string name;
    int coffee, milk;
    bool brewed;
    bool mixed;
    Cup *cup;

public:
    Coffee(const std::string &name, int coffee, int milk)
            : name(name), coffee(coffee), milk(milk), brewed(false), mixed(false), cup(nullptr) {}
    void brew() {
        this->brewed = true;
    }
    void mix() {
        this->mixed = true;
    }
    void pour_into(Cup *cup) {
        this->cup = cup;
        cup->hold_coffee(this);
    }
    ~Coffee() {
        this->cup->hold_coffee(nullptr);
        std::cout << "Washed " << this->cup->id() << " cup." << std::endl;
    }
    void drink() {
        std::cout << "Drinking " << this->name << " (";
        float total = (this->coffee + this->milk) / 100.0f;
        if (total == 0.0f) total = 1.0f;
        std::cout << static_cast<int>(round(this->coffee / total)) << "% coffee";
        std::cout << " and ";
        std::cout << static_cast<int>(round(this->milk / total)) << "% milk";
        if (this->brewed || this->mixed) {
            std::cout << " that is";
            if (this->brewed) std::cout << " brewed";
            if (this->brewed && this->mixed) std::cout << " and";
            if (this->mixed) std::cout << " mixed";
        }
        std::cout << ") from " << this->cup->id() << " cup.";
        std::cout << std::endl;
    }
};

#endif
